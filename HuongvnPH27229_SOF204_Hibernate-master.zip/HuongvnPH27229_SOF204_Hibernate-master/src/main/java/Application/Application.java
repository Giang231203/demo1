
package Application;

import Views.FrmDetails;

/**
 *
 * @author Vũ Nguyên Hướng
 */
public class Application {

    public static void main(String[] args) {
        new FrmDetails().setVisible(true);
    }
    
}
